Change Log: `yii2-dialog`
===================================

## Version 1.0.0

**Date:** 22-Feb-2016

- Initial release
- (enh #1): Add Dutch translations
